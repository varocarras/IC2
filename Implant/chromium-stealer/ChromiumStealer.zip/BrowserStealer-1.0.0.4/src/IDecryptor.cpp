﻿#include "IDecryptor.h"
