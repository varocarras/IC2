﻿#include "ICollector.h"
