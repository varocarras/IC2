## BrowserStealer (Chrome / Firefox / Microsoft Edge)
----------------------------------------------------
### (Chrome - all chromium based and Firefox - all gecko based)
Simple password/cookies/history/bookmarks stealer/dumper for chrome all version (includes 80+), microsoft edge browser,includes all chromium based browsers, and all gecko based browser (firefox etc.). 

- It's can find firefox from non standart location.
- All WinApi calls has import table obfucation.
- Support Chromium based Browsers (Google Chrome, Microsoft Edge and etc.)
- Support Gecko based browsers (Firefox and etc.) (warning: if browser x64 you need use x64 build)
- Hidden import table (hidden - shell32, functions from kernel32, bcrypt and etc.)
- Small size
- Full actions based on hidden winapi calls
- No dependencies (almost all code is c or mix c++ with minimal using)
- Added static linking for no dependencies.

--------------------------------------------------

### Rule of using
Software provides AS IS. Author not answer for any illigal using software.

--------------------------------------------------

### Small proof of concept

![alt text](https://raw.githubusercontent.com/SaulBerrenson/BrowserStealer/main/miscs/proof/DOoS5hYVlu.gif)

--------------------------------------------------
### Language
![C++](https://img.shields.io/badge/-C%2B%2B%2014-%2300599C?style=plastic&logo=cplusplus)

--------------------------------------------------
### Support Dump Info for List Browsers:

| № | Browser Name | Passwords | Cookies | History | Bookmarks |
| --- | --- | --- | --- | --- | --- |
| 1 | Chrome | &#9989; | &#9989; | &#8987; | &#8987; |
| 2 | Microsoft Edge | &#9989; | &#9989; | &#8987; | &#8987; |
| 3 | Chromium | &#9989; | &#9989; | &#8987; | &#8987; |
| 4 | Brave - Browser | &#9989; | &#9989; | &#8987; | &#8987; |
| 5 | Epic Privacy Browser | &#9989; | &#9989; | &#8987; | &#8987; |
| 6 | Amigo | &#9989; | &#9989; | &#8987; | &#8987; |
| 7 | Vivaldi | &#9989; | &#9989; | &#8987; | &#8987; |
| 8 | Orbitum | &#9989; | &#9989; | &#8987; | &#8987; |
| 9 | Atom | &#9989; | &#9989; | &#8987; | &#8987; |
| 10 | Kometa | &#9989; | &#9989; | &#8987; | &#8987; |
| 11 | Comodo Dragon | &#9989; | &#9989; | &#8987; | &#8987; |
| 12 | Torch | &#9989; | &#9989; | &#8987; | &#8987; |
| 13 | Slimjet | &#9989; | &#9989; | &#8987; | &#8987; |
| 14 | 360Browser | &#9989; | &#9989; | &#8987; | &#8987; |
| 15 | Maxthon3 | &#9989; | &#9989; | &#8987; | &#8987; |
| 16 | K - Melon | &#9989; | &#9989; | &#8987; | &#8987; |
| 17 | Sputnik | &#9989; | &#9989; | &#8987; | &#8987; |
| 18 | Nichrome | &#9989; | &#9989; | &#8987; | &#8987; |
| 19 | CocCoc Browser | &#9989; | &#9989; | &#8987; | &#8987; |
| 20 | Uran | &#9989; | &#9989; | &#8987; | &#8987; |
| 21 | Chromodo | &#9989; | &#9989; | &#8987; | &#8987; |
| 22 | Yandex(old) | &#9989; | &#9989; | &#8987; | &#8987; |
| 23 | Firefox | &#9989; | &#9989; | &#8987; | &#8987; |
| 24 | Waterfox | &#9989; | &#9989; | &#8987; | &#8987; |
| 25 | Cyberfox | &#9989; | &#9989; | &#8987; | &#8987; |
| 26 | K - Meleon | &#9989; | &#9989; | &#8987; | &#8987; |
| 27 | Thunderbird | &#9989; | &#9989; | &#8987; | &#8987; |
| 28 | IceDragon | &#9989; | &#9989; | &#8987; | &#8987; |
| 29 | BlackHaw | &#9989; | &#9989; | &#8987; | &#8987; |
| 30 | Pale Moon | &#9989; | &#9989; | &#8987; | &#8987; |
--------------------------------------------------

### Build Manual without IDE
&#8987;

### Additional Features
Html report - &#8987;
--------------------------------------------------
