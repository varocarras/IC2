import matplotlib.pyplot as plt
import random
import numpy as np
q = []
d = []
def sigmoidplot(n):
    op = 1/(1+(np.power(2.71828182846, (-1*n))))
    return op
for x in range(0,25):
    q.append(sigmoidplot(x))
    
plt.plot(q)

plt.ylabel("Y")
plt.show()

