import socket
#destination = raw_input("Enter Destination: ", )
#text = raw_input("Enter text: ", )
text = ""
text = str(text)
destination = "10.122.56."

def socketsend(text, destination):

    UDP_IP = destination
        
    UDP_PORT = 2001
    MESSAGE = text

    print "UDP target IP:", UDP_IP
    print "UDP target port:", UDP_PORT
    print "message:", MESSAGE

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))



text = raw_input("Enter text: ", )
for x in range(0, 99):
    text = str(text)
    destination = destination + str(x)
    print(destination)
    socketsend(text, destination)
    destination = "10.122.56."