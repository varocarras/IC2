import socket
text ='hh'

destination = "10.122.56.101"
pdestination = "10.122.59.255"

def ssocketsend(txt, destination):
    UDP_IP = destination
    UDP_PORT = 2001
    MESSAGE =  txt
    print("SENDING TO: " + UDP_IP)
    print("ON PORT: ", UDP_PORT)
    print("MESSAGE " + MESSAGE)
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
def psocketsend(txt, pdestination):
    UDP_IP = pdestination
    UDP_PORT = 2001
    MESSAGE =  txt
    print("BROADCASTING TO: ", UDP_IP)
    print("ON PORT: ", UDP_PORT)
    print("MESSAGE " + MESSAGE)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
    sock.sendto(txt, (pdestination, UDP_PORT))
while(True):
    text = input("rs3:")
    text = str(text)
    if(text[0] == "B"):
        text = text[1:]    
        for x in range(0, 5):
            psocketsend(text, pdestination)
    elif(text[0] == "S"):
        text = text[1:]
        for x in range(0, 5):
            ssocketsend(text, destination)
    elif(text == "pkeymode"):
        keymode = True
        while(keymode == True):
            txt2 = input("RS3:KM: ",)
            txt2 = str(txt2)
            if(txt2 == "ko"):
                keymode = False
            else:
                txt2 = "N:k{" + txt2 + "}"
                for x in range(0, 5):
                    psocketsend(txt2, pdestination)
    elif(text == "skeymode"):
        keymode = True
        while(keymode == True):
            txt2 = input("RS3:KM: ",)
            txt2 = str(txt2)
            if(txt2 == "ko"):
                keymode = False
            else:
                txt2 = "N:k{" + txt2 + "}"
                for x in range(0, 5):
                    ssocketsend(txt2, destination)
        
    
