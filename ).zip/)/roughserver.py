import socket
#destination = raw_input("Enter Destination: ", )
text = raw_input("Enter text: ", )
text = str(text)
destination = "10.122.56.125"
#destination = "127.0.0.1"
def socketsend(text, destination):

    UDP_IP = destination
        
    UDP_PORT = 2001
    MESSAGE = text

    print "UDP target IP:", UDP_IP
    print "UDP target port:", UDP_PORT
    print "message:", MESSAGE

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))

while(True):
    text = raw_input("Enter text: ", )
    text = str(text)
    for x in range(0, 5):
        socketsend(text, destination)
    